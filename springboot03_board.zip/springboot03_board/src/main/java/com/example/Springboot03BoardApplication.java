package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot03BoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot03BoardApplication.class, args);
	}

}
