package com.example.board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot03BoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
